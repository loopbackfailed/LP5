import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Hello extends UnicastRemoteObject implements HelloInterface {

    public Hello() throws RemoteException {
        super(); // Export object on anonymous port
    }

    // Each client will call this with their name
    public String say(String clientName) throws RemoteException {
        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        System.out.println("Client " + clientName + " invoked say() at " + time);
        return "Hello, " + clientName + "! [Server time: " + time + "]";
    }
}