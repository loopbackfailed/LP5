import java.rmi.Naming;

public class HelloClient {

    static class ClientWorker extends Thread {
        private String name;

        public ClientWorker(String name) {
            this.name = name;
        }

        public void run() {
            try {
                HelloInterface stub = (HelloInterface) Naming.lookup("//localhost/HelloService");
                String response = stub.say(name);
                System.out.println("Response for " + name + ": " + response);
            } catch (Exception e) {
                System.err.println("Exception for " + name + ": " + e);
            }
        }
    }

    public static void main(String[] args) {
        // Simulate 5 concurrent clients
        for (int i = 1; i <= 5; i++) {
            new ClientWorker("Client" + i).start();
        }
    }
}