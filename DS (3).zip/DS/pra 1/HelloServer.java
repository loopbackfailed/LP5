
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class HelloServer {
    public static void main(String[] args) {
        try {
            // Start RMI Registry
            LocateRegistry.createRegistry(1099); // default port
            Hello obj = new Hello();
            Naming.rebind("HelloService", obj);
            System.out.println("HelloServer is ready.");
        } catch (RemoteException re) {
            System.err.println("RemoteException: " + re);
        } catch (Exception e) {
            System.err.println("Exception: " + e);
        }
    }
}
