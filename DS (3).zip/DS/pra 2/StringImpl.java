import StringApp.StringOperationsPOA;

public class StringImpl extends StringOperationsPOA {
    public String toUpper(String str) {
        return str.toUpperCase();
    }

    public String toLower(String str) {
        return str.toLowerCase();
    }

    public String reverse(String str) {
        return new StringBuilder(str).reverse().toString();
    }
}
