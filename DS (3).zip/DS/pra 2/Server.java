import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import StringApp.StringOperations;
import StringApp.StringOperationsHelper;

public class Server {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

            StringImpl stringImpl = new StringImpl();
            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(stringImpl);

            StringOperations href = StringOperationsHelper.narrow(ref);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            NameComponent path[] = ncRef.to_name("StringOperations");
            ncRef.rebind(path, href);

            System.out.println("Server ready and waiting...");
            orb.run();
        } catch (Exception e) {
            System.err.println("Server Error: " + e);
            e.printStackTrace();
        }
    }
}