
import StringApp.StringOperations;
import StringApp.StringOperationsHelper;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;

public class Client {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            StringOperations strObj = StringOperationsHelper.narrow(ncRef.resolve_str("StringOperations"));

            System.out.println("Calling toUpper(\"hello\") → " + strObj.toUpper("hello"));
            System.out.println("Calling toLower(\"WORLD\") → " + strObj.toLower("WORLD"));
            System.out.println("Calling reverse(\"CORBA\") → " + strObj.reverse("CORBA"));

        } catch (Exception e) {
            System.err.println("ERROR : " + e);
            e.printStackTrace(System.out);
        }
    }
}