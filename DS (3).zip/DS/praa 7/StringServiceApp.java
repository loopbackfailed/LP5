import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;

public class StringServiceApp {

    // Helper to read InputStream fully
    private static String readStream(InputStream is) throws IOException {
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int length;
        while ((length = is.read(buffer)) != -1) {
            result.write(buffer, 0, length);
        }
        return result.toString("UTF-8");
    }

    // Web Service Handler
    static class StringHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                String body = readStream(exchange.getRequestBody());

                String[] parts = body.split(";");
                String operation = parts[0]; // toUpper, toLower, reverse
                String text = parts[1];

                String result;
                switch (operation) {
                    case "toUpper":
                        result = text.toUpperCase();
                        break;
                    case "toLower":
                        result = text.toLowerCase();
                        break;
                    case "reverse":
                        result = new StringBuilder(text).reverse().toString();
                        break;
                    default:
                        result = "Invalid operation";
                }

                exchange.sendResponseHeaders(200, result.length());
                OutputStream os = exchange.getResponseBody();
                os.write(result.getBytes());
                os.close();
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }
    }

    // Client that consumes the Web Service
    public static void callWebService(String operation, String text) throws IOException {
        URL url = new URL("http://localhost:8000/string");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);

        String requestBody = operation + ";" + text;
        OutputStream os = conn.getOutputStream();
        os.write(requestBody.getBytes());
        os.flush();
        os.close();

        String result = readStream(conn.getInputStream());
        System.out.println("Response from web service: " + result);
        conn.disconnect();
    }

    public static void main(String[] args) throws Exception {
        // Start the Web Service
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/string", new StringHandler());
        server.setExecutor(null);
        server.start();
        System.out.println("Web Service started at http://localhost:8000/string");

        // Wait a moment to ensure server is ready
        Thread.sleep(1000);

        // Client calls the web service
        callWebService("toUpper", "hello world");
        callWebService("toLower", "HELLO JAVA");
        callWebService("reverse", "Distributed");
    }
}

/*
 * 
 * javac StringServiceApp.java
 * 
 * java StringServiceApp
 * 
 */