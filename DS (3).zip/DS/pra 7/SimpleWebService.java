import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class SimpleWebService {

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/greet", new GreetHandler());
        server.setExecutor(null); // creates a default executor
        System.out.println("Server started at http://localhost:8000/greet");
        server.start();
    }

    static class GreetHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String query = exchange.getRequestURI().getQuery();
            String name = "Guest";

            if (query != null && query.contains("name=")) {
                name = query.split("name=")[1];
            }

            String response = "{\"message\": \"Hello, " + name + "!\"}";
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, response.length());

            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}

// Compile and Run:
// javac SimpleWebService.java
// java SimpleWebService