import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WebServiceClient {

    public static void main(String[] args) {
        try {
            String name = "Hello Webserver";
            URL url = new URL("http://localhost:8000/greet?name=" + name);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : "
                        + conn.getResponseCode());
            }

            InputStream is = conn.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String output;
            StringBuilder responseBuilder = new StringBuilder();

            while ((output = br.readLine()) != null) {
                responseBuilder.append(output);
            }

            conn.disconnect();

            String jsonResponse = responseBuilder.toString();
            // Simple manual JSON parsing (avoid dependency)
            String message = jsonResponse.split(":")[1].replace("}", "").replace("\"", "").trim();
            System.out.println("Server Response: " + message);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

// Compile and Run:
// javac WebServiceClient.java
// java WebServiceClient
