import java.util.Arrays;
import java.util.Scanner;

public class BerkeleyClockSync {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Take user input for number of clocks
        System.out.print("Enter the number of clocks: ");
        int n = scanner.nextInt();
        int[] clocks = new int[n];

        // Step 2: Take clock values from the user
        System.out.println("Enter the time values for each clock (in seconds):");
        for (int i = 0; i < n; i++) {
            System.out.print("Clock " + (i + 1) + ": ");
            clocks[i] = scanner.nextInt();
        }

        int masterIndex = 0; // Assume the first clock as the master

        System.out.println("\nInitial Clocks: " + Arrays.toString(clocks));

        // Step 3: Master calculates the time difference
        int sum = 0, count = 0;
        for (int i = 0; i < clocks.length; i++) {
            if (i != masterIndex) {
                sum += clocks[i] - clocks[masterIndex];
                count++;
            }
        }

        int averageDiff = count == 0 ? 0 : sum / count; // Avoid division by zero
        System.out.println("\nAverage Time Difference: " + averageDiff);

        // Step 4: Synchronize all clocks based on the calculated average
        for (int i = 0; i < clocks.length; i++) {
            if (i != masterIndex) {
                clocks[i] -= (clocks[masterIndex] - averageDiff - clocks[i]);
            }
        }
        clocks[masterIndex] += averageDiff; // Adjust master clock

        System.out.println("\nSynchronized Clocks: " + Arrays.toString(clocks));

        scanner.close();
    }
}

/*
 * javac BerkeleyClockSync.java
 * 
 * java BerkeleyClockSync
 * 
 */